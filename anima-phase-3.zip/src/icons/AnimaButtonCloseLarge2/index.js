export { AnimaButtonCloseLarge2 } from "./AnimaButtonCloseLarge2";
