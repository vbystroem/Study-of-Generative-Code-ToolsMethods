export { AnimaButtonCloseLarge3 } from "./AnimaButtonCloseLarge3";
