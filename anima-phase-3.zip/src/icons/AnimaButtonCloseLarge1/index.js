export { AnimaButtonCloseLarge1 } from "./AnimaButtonCloseLarge1";
