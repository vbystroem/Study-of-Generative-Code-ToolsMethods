export { AnimaCard } from "./AnimaCard";
