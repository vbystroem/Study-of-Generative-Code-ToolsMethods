import { AnimaButtonLarge } from ".";

export default {
  title: "Components/AnimaButtonLarge",
  component: AnimaButtonLarge,
};

export const Default = {
  args: {
    className: {},
    text: "Välj från lista",
  },
};
