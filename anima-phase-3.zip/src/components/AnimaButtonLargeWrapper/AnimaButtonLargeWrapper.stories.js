import { AnimaButtonLargeWrapper } from ".";

export default {
  title: "Components/AnimaButtonLargeWrapper",
  component: AnimaButtonLargeWrapper,
};

export const Default = {
  args: {
    choiceButtonClassName: {},
    text: "Nej, inte den",
  },
};
