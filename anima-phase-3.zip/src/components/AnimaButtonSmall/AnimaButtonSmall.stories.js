import { AnimaButtonSmall } from ".";

export default {
  title: "Components/AnimaButtonSmall",
  component: AnimaButtonSmall,
};

export const Default = {
  args: {
    className: {},
  },
};
